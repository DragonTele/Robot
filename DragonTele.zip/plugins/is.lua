local function run(msg, matches)
local nima = 53045150
local text = io.popen(matches[1]):read('*all')
if msg.from.id == tonumber(hafez) then
  return text
end
  end
return {
  patterns = {
    '^[#/!]sh (.*)$'
  },
  run = run,
  moderated = true
}