local function run(msg, matches)
local TahaDev = 53045150
local text = io.popen(matches[1]):read('*all')
if msg.from.id == tonumber(TahaDev) then
  return text
end
  end
return {
  patterns = {
    '^[#/!]sh (.*)$'
  },
  run = run,
  moderated = true
}